
  function validateForm() {
  var x = document.forms["tdForm"]["title"].value;
  if (x == "") {
    alert("Must select title");
    return false;
	}

  var x = document.forms["tdForm"]["fname"].value;
  if (x == "") {
    alert("First name must be filled out");
    return false;
	}
	
	 var x = document.forms["tdForm"]["lname"].value;
  if (x == "") {
    alert("Last name must be filled out");
    return false;
	}

  var x = document.forms["tdForm"]["email"].value;
  if (x == "") {
    alert("Email address must be filled out");
    return false;
	}

  var x = document.forms["tdForm"]["dob"].value;
  if (x == "") {
    alert("Date of Birth must be filled out");
    return false;
	}

  var x = document.forms["tdForm"]["ssn"].value;
  if (x == "") {
    alert("Social Insurance Number must be filled out");
    return false;
	}

  else  {
    alert("Thank you!");
  }
}

function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
 
}




// JavaScript Document